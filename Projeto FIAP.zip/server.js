const express = require("express");
const sqlite = require("sqlite3").verbose();
const parser = require("body-parser");

const PORT = 8000;

const app = express();
const db = new sqlite.Database(__dirname + "/user");

app.set('view engine', 'ejs');

app.use(express.static(__dirname + "/static"))
app.use(parser.urlencoded())

app.get("/", (req, res) => {
      res.render("pages/index")
})

app.get("/busca", (req, res) => {
      res.render("pages/busca");
})

app.get("/cadastro", (req, res) => {
      res.render("pages/cadastro");
})

app.get("/listar", (req, res) => {
      db.all("SELECT * FROM user;", (err, rows) => {
            if (err || rows.length == 0) {
                  res.render("pages/listar", { result: "Nenhum usuário encontrado!" })
            } else {
                  res.render("pages/listar", { result: rows })
            }
      });
})

app.get("/buscaCPF", (req, res) => {
      let cpf = req.query["cpf"];
      let sql = `SELECT * FROM user WHERE CPF LIKE '%${cpf}%';`;
      db.all(sql, (err, row) => {
            if (err || row.length == 0) {
                  res.render("pages/busca", { result: "Usuário não encontrado!", url: cpf })
            } else {
                  res.render("pages/busca", { result: row, url: cpf })
            }
      })
});

app.post("/cadastro", (req, res) => {
      let { nome, cpf, telefone, email, tipoConta, endereco, dataNascimento } = req.body;

      let idade = getAge(dataNascimento);

      let dataCadastro = (new Date()).toLocaleDateString().replace(/\-/g, "/");
      dataNascimento = (new Date(dataNascimento)).toLocaleDateString().replace(/\-/g, "/")

      let sql = `INSERT INTO user (nome, cpf, idade, tel, email, tipoConta, end, dataNascimento, dataCadastro) VALUES ('${nome}', '${cpf}', ${idade} ,'${telefone}', '${email}' ,'${tipoConta}', '${endereco}', '${dataNascimento}', '${dataCadastro}')`
      db.exec(sql, (err) => {
            if (err) {
                  if (err.errno == 1) {
                        res.render("pages/cadastro", { error: "Usuário já existe!" })
                  }
            } else {
                  res.redirect("/");
            }
      })
})

app.listen(PORT, () => { console.log(`Listening on http://localhost:${PORT}`) });

function getAge(dateString) {
      var today = new Date();
      var birthDate = new Date(dateString);
      var age = today.getFullYear() - birthDate.getFullYear();
      return age;
}